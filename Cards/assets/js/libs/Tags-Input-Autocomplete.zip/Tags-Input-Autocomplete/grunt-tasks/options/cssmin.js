module.exports = {
    options: {
	    shorthandCompacting: false
    },
    plugin: {
	    files: {
		    'dist/jquery.tagsinput-revisited.min.css': ['src/jquery.tagsinput-revisited.css']
	    }
    }
};
