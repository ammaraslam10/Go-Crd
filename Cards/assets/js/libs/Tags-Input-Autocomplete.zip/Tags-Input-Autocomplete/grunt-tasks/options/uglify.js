module.exports = {
    options: {
	    mangle: true
    },
    plugin: {
	    files: {
		    'dist/jquery.tagsinput-revisited.min.js': ['src/jquery.tagsinput-revisited.js']
	    }
    }
};
